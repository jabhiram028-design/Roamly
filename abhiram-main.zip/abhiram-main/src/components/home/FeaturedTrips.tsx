import React from 'react';
import { useApp } from '../../context/AppContext';
import { FEATURED_TRIPS } from '../../data/mockData';
import { Clock, MapPin, Star, Heart, ArrowRight } from 'lucide-react';

export const FeaturedTrips: React.FC = () => {
  const { navigateToTrip, openBookingModal, setActiveTab, toggleWishlist, isInWishlist } = useApp();

  const packagesList = FEATURED_TRIPS.slice(0, 3);

  return (
    <section className="py-20 font-sans">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">

        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-4">
          <div>
            <span className="text-xs font-bold uppercase tracking-widest text-[#1769E8]">
              Curated Packages
            </span>
            <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-[#101C35] mt-1">
              Featured Trips
            </h2>
            <p className="text-base sm:text-lg text-[#4B5563] max-w-2xl mt-3 font-normal">
              Handpicked itineraries for unforgettable journeys.
            </p>
          </div>

          <button
            onClick={() => setActiveTab('trips')}
            className="inline-flex items-center gap-2 text-sm font-bold text-[#1769E8] hover:text-[#1253BD] group cursor-pointer shrink-0"
          >
            <span>View All Trips</span>
            <ArrowRight className="w-5 h-5 transition-transform group-hover:translate-x-1" />
          </button>
        </div>

        {/* 3 Package Cards */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {packagesList.map((pkg) => {
            const favorited = isInWishlist(pkg.id);
            return (
              <div
                key={pkg.id}
                className="bg-white rounded-3xl overflow-hidden shadow-card hover:shadow-floating border border-gray-100 transition-all duration-300 flex flex-col justify-between group"
              >

                {/* Image Section */}
                <div
                  className="relative h-72 overflow-hidden cursor-pointer"
                  onClick={() => navigateToTrip(pkg.id)}
                >
                  <img
                    src={pkg.heroImage}
                    alt={pkg.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700 ease-out"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent opacity-80" />

                  {/* Duration Badge */}
                  <div className="absolute top-4 left-4 bg-white/95 backdrop-blur-md px-3.5 py-1.5 rounded-full text-xs font-bold text-[#101C35] flex items-center gap-1.5 shadow-sm">
                    <Clock className="w-3.5 h-3.5 text-[#1769E8]" />
                    <span>{pkg.durationDays} Days</span>
                  </div>

                  {/* Wishlist Heart Button */}
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      toggleWishlist(pkg.id);
                    }}
                    title={favorited ? 'Remove from wishlist' : 'Add to wishlist'}
                    className={`absolute top-4 right-4 p-2.5 rounded-full backdrop-blur-md transition-all cursor-pointer ${
                      favorited
                        ? 'bg-red-500 text-white shadow-md'
                        : 'bg-white/80 hover:bg-white text-gray-700 hover:text-red-500'
                    }`}
                  >
                    <Heart className={`w-4 h-4 ${favorited ? 'fill-white' : ''}`} />
                  </button>

                  {/* Location Tag */}
                  <div className="absolute bottom-4 left-4 text-white flex items-center gap-1.5 text-xs font-semibold">
                    <MapPin className="w-4 h-4 text-[#1769E8]" />
                    <span>{pkg.location}</span>
                  </div>
                </div>

                {/* Content Section */}
                <div className="p-6 flex-1 flex flex-col justify-between">
                  <div>
                    <div className="flex items-center justify-between gap-2 mb-2">
                      <span className="text-xs font-bold uppercase tracking-wider text-[#1769E8] bg-[#EAF5FF] px-2.5 py-0.5 rounded-md">
                        {pkg.category}
                      </span>
                      <div className="flex items-center gap-1 text-xs font-bold text-[#101C35]">
                        <Star className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
                        <span>{pkg.rating}</span>
                      </div>
                    </div>

                    <h3
                      onClick={() => navigateToTrip(pkg.id)}
                      className="font-serif text-2xl font-bold text-[#101C35] group-hover:text-[#1769E8] transition-colors cursor-pointer leading-tight"
                    >
                      {pkg.title}
                    </h3>

                    <p className="text-sm text-[#4B5563] mt-2 line-clamp-2 leading-relaxed">
                      {pkg.shortDescription}
                    </p>
                  </div>

                  {/* Pricing & Actions */}
                  <div className="pt-6 mt-6 border-t border-gray-100 flex items-center justify-between">
                    <div>
                      <span className="text-xs text-gray-400 block font-medium">Starting from</span>
                      <div className="flex items-baseline gap-1.5">
                        <span className="text-2xl font-bold text-[#101C35]">
                          ${pkg.startingPrice.toLocaleString()}
                        </span>
                        {pkg.originalPrice && (
                          <span className="text-xs text-gray-400 line-through">
                            ${pkg.originalPrice.toLocaleString()}
                          </span>
                        )}
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => navigateToTrip(pkg.id)}
                        className="px-4 py-2.5 rounded-xl border border-gray-200 text-[#101C35] hover:bg-gray-50 text-xs font-bold transition-colors cursor-pointer"
                      >
                        View Trip
                      </button>
                      <button
                        onClick={() => openBookingModal(pkg)}
                        className="px-4 py-2.5 rounded-xl bg-[#1769E8] hover:bg-[#1253BD] text-white text-xs font-bold transition-all cursor-pointer shadow-sm"
                      >
                        Book Now
                      </button>
                    </div>

                  </div>

                </div>

              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
};
