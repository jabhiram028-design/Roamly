import React from 'react';
import { useApp } from '../context/AppContext';
import { DESTINATIONS, FEATURED_TRIPS } from '../data/mockData';
import { Star, Calendar, DollarSign, Heart, ArrowLeft, CheckCircle2, Bed, Info } from 'lucide-react';

export const DestinationDetailPage: React.FC = () => {
  const {
    selectedDestinationId,
    setActiveTab,
    navigateToDestination,
    openBookingModal,
    toggleWishlist,
    isInWishlist
  } = useApp();

  const destination = DESTINATIONS.find((d) => d.id === selectedDestinationId) || DESTINATIONS[0];
  const favorited = isInWishlist(destination.id);

  const relatedTrips = FEATURED_TRIPS.filter(
    (t) => t.destinationId === destination.id || t.country === destination.country
  );

  const relatedDestinations = DESTINATIONS.filter((d) => d.id !== destination.id).slice(0, 3);

  return (
    <div className="pt-20 font-sans bg-[#F8F8F5] min-h-screen">

      {/* Hero Header */}
      <div className="relative h-[65vh] min-h-[450px] overflow-hidden">
        <img
          src={destination.heroImage}
          alt={destination.name}
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-black/20" />

        {/* Top Floating Controls */}
        <div className="absolute top-8 left-0 right-0 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between z-10">
          <button
            onClick={() => setActiveTab('destinations')}
            className="inline-flex items-center gap-2 bg-white/90 backdrop-blur-md hover:bg-white text-[#101C35] font-semibold text-xs px-4 py-2 rounded-full shadow-sm transition-all cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" /> Back to Destinations
          </button>

          <button
            onClick={() => toggleWishlist(destination.id)}
            className={`p-2.5 rounded-full backdrop-blur-md transition-all cursor-pointer ${
              favorited ? 'bg-red-500 text-white shadow-md' : 'bg-white/90 text-gray-700 hover:bg-white'
            }`}
          >
            <Heart className={`w-5 h-5 ${favorited ? 'fill-white' : ''}`} />
          </button>
        </div>

        {/* Hero Title Container */}
        <div className="absolute bottom-10 left-0 right-0 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-white z-10">
          <div className="flex flex-wrap items-center gap-2 text-xs font-bold uppercase tracking-widest text-sky-200 mb-2">
            <span>{destination.continent}</span>
            <span>•</span>
            <span>{destination.country}</span>
            <span>•</span>
            <span className="bg-white/20 backdrop-blur-md px-2.5 py-0.5 rounded-md text-white">
              {destination.category}
            </span>
          </div>

          <h1 className="font-serif text-4xl sm:text-6xl font-bold tracking-tight">
            {destination.name}
          </h1>
          <p className="text-lg sm:text-xl text-gray-200 mt-2 max-w-2xl font-light">
            {destination.shortDescription}
          </p>

          <div className="flex flex-wrap items-center gap-6 mt-6 text-sm font-semibold">
            <div className="flex items-center gap-1.5 bg-white/15 backdrop-blur-md px-3.5 py-1.5 rounded-full">
              <Star className="w-4 h-4 text-amber-400 fill-amber-400" />
              <span>{destination.rating} ({destination.reviewsCount} reviews)</span>
            </div>
            <div className="flex items-center gap-1.5 bg-white/15 backdrop-blur-md px-3.5 py-1.5 rounded-full">
              <Calendar className="w-4 h-4 text-sky-300" />
              <span>Best: {destination.bestTimeToVisit}</span>
            </div>
            <div className="flex items-center gap-1.5 bg-white/15 backdrop-blur-md px-3.5 py-1.5 rounded-full">
              <DollarSign className="w-4 h-4 text-emerald-400" />
              <span>~${destination.averagePricePerDay} / day</span>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content Details Grid */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">

          {/* Main 2 Columns */}
          <div className="lg:col-span-2 space-y-12">

            {/* Overview Section */}
            <div className="bg-white rounded-3xl p-8 shadow-card border border-gray-100 space-y-6">
              <h2 className="font-serif text-3xl font-bold text-[#101C35]">
                About {destination.name}
              </h2>
              <p className="text-base text-[#4B5563] leading-relaxed">
                {destination.fullDescription}
              </p>

              {/* Suggested Activities Checklist */}
              <div className="pt-6 border-t border-gray-100">
                <h3 className="font-serif text-xl font-bold text-[#101C35] mb-4">
                  Top Recommended Experiences
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {destination.suggestedActivities.map((act, i) => (
                    <div key={i} className="flex items-start gap-3 bg-[#F8F8F5] p-3.5 rounded-xl border border-gray-200/60 text-sm text-[#101C35] font-medium">
                      <CheckCircle2 className="w-5 h-5 text-[#1769E8] shrink-0 mt-0.5" />
                      <span>{act}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Popular Attractions */}
            {destination.popularAttractions.length > 0 && (
              <div className="space-y-6">
                <h2 className="font-serif text-3xl font-bold text-[#101C35]">
                  Key Landmarks & Attractions
                </h2>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                  {destination.popularAttractions.map((attr, index) => (
                    <div key={index} className="bg-white rounded-2xl overflow-hidden shadow-card border border-gray-100">
                      <img
                        src={attr.image}
                        alt={attr.name}
                        className="w-full h-48 object-cover"
                      />
                      <div className="p-5">
                        <h4 className="font-serif text-xl font-bold text-[#101C35]">
                          {attr.name}
                        </h4>
                        <p className="text-sm text-gray-600 mt-2 leading-relaxed">
                          {attr.description}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Photo Gallery Grid */}
            {destination.galleryImages.length > 0 && (
              <div className="space-y-4">
                <h2 className="font-serif text-2xl font-bold text-[#101C35]">
                  Photo Gallery
                </h2>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  {destination.galleryImages.map((img, idx) => (
                    <img
                      key={idx}
                      src={img}
                      alt={`${destination.name} photo ${idx + 1}`}
                      className="w-full h-44 rounded-2xl object-cover hover:scale-105 transition-transform cursor-pointer shadow-sm"
                    />
                  ))}
                </div>
              </div>
            )}

            {/* Travel Tips Callout */}
            {destination.travelTips.length > 0 && (
              <div className="bg-[#EAF5FF] rounded-3xl p-8 border border-[#1769E8]/30 space-y-4">
                <div className="flex items-center gap-3 text-[#1769E8]">
                  <Info className="w-6 h-6" />
                  <h3 className="font-serif text-2xl font-bold text-[#101C35]">
                    Insider Travel Advice
                  </h3>
                </div>
                <ul className="space-y-3 text-sm text-[#4B5563]">
                  {destination.travelTips.map((tip, idx) => (
                    <li key={idx} className="flex items-start gap-2">
                      <span className="w-2 h-2 rounded-full bg-[#1769E8] mt-2 shrink-0" />
                      <span>{tip}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}

          </div>

          {/* Sidebar (1 Column) */}
          <div className="space-y-8">

            {/* Booking Inquiry Card */}
            <div className="bg-white rounded-3xl p-6 shadow-floating border border-gray-100 space-y-6 sticky top-24">
              <div className="border-b border-gray-100 pb-4">
                <span className="text-xs font-bold uppercase tracking-wider text-[#1769E8]">
                  Plan Your Trip
                </span>
                <h3 className="font-serif text-2xl font-bold text-[#101C35] mt-1">
                  Visit {destination.name}
                </h3>
                <p className="text-xs text-gray-500 mt-1">
                  Customized itineraries & bespoke concierge service.
                </p>
              </div>

              <div className="space-y-3 text-sm">
                <div className="flex justify-between py-2 border-b border-gray-100">
                  <span className="text-gray-500">Region:</span>
                  <span className="font-semibold text-[#101C35]">{destination.region}</span>
                </div>
                <div className="flex justify-between py-2 border-b border-gray-100">
                  <span className="text-gray-500">Best Season:</span>
                  <span className="font-semibold text-[#101C35]">{destination.bestTimeToVisit}</span>
                </div>
                <div className="flex justify-between py-2">
                  <span className="text-gray-500">Avg Daily Cost:</span>
                  <span className="font-bold text-[#1769E8]">${destination.averagePricePerDay} USD</span>
                </div>
              </div>

              <button
                onClick={() => {
                  if (relatedTrips.length > 0) {
                    openBookingModal(relatedTrips[0]);
                  } else {
                    openBookingModal();
                  }
                }}
                className="w-full bg-[#1769E8] hover:bg-[#1253BD] text-white font-semibold py-3.5 rounded-xl shadow-md transition-all cursor-pointer text-center block"
              >
                Inquire & Book Experience
              </button>

              <button
                onClick={() => toggleWishlist(destination.id)}
                className="w-full py-3 border border-gray-200 text-[#101C35] font-semibold rounded-xl text-sm hover:bg-gray-50 transition-colors flex items-center justify-center gap-2 cursor-pointer"
              >
                <Heart className={`w-4 h-4 ${favorited ? 'fill-red-500 text-red-500' : ''}`} />
                {favorited ? 'Saved in Wishlist' : 'Save to Wishlist'}
              </button>
            </div>

            {/* Accommodations */}
            {destination.accommodations.length > 0 && (
              <div className="bg-white rounded-3xl p-6 shadow-card border border-gray-100 space-y-4">
                <h4 className="font-serif text-xl font-bold text-[#101C35] flex items-center gap-2">
                  <Bed className="w-5 h-5 text-[#1769E8]" /> Recommended Stays
                </h4>
                {destination.accommodations.map((acc, i) => (
                  <div key={i} className="flex items-center gap-3 p-2.5 rounded-xl hover:bg-gray-50 border border-gray-100">
                    <img
                      src={acc.image}
                      alt={acc.name}
                      className="w-14 h-14 rounded-lg object-cover"
                    />
                    <div>
                      <h5 className="text-sm font-bold text-[#101C35]">{acc.name}</h5>
                      <p className="text-xs text-gray-500">{acc.type} • {acc.priceRange}</p>
                      <span className="text-xs font-bold text-amber-500 flex items-center gap-0.5 mt-0.5">
                        <Star className="w-3 h-3 fill-amber-400" /> {acc.rating}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}

          </div>

        </div>

        {/* Related Destinations */}
        <div className="mt-20 pt-12 border-t border-gray-200">
          <h2 className="font-serif text-3xl font-bold text-[#101C35] mb-8">
            You Might Also Love
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
            {relatedDestinations.map((rel) => (
              <div
                key={rel.id}
                onClick={() => navigateToDestination(rel.id)}
                className="bg-white rounded-2xl overflow-hidden shadow-card border border-gray-100 group cursor-pointer"
              >
                <img
                  src={rel.heroImage}
                  alt={rel.name}
                  className="w-full h-44 object-cover group-hover:scale-105 transition-transform"
                />
                <div className="p-4">
                  <span className="text-xs text-[#1769E8] font-bold uppercase">{rel.country}</span>
                  <h4 className="font-serif text-xl font-bold text-[#101C35] group-hover:text-[#1769E8] transition-colors">
                    {rel.name}
                  </h4>
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>
    </div>
  );
};
